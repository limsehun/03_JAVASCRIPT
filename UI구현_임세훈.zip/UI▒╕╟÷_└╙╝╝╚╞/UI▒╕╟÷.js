function readValue(){
    const bg = document.querySelector('#background');
    const input = document.querySelector("#textInput");
    const container = document.querySelector('[target-td = css-td]')
    const tagList = document.getElementsByTagName("#색");
    const wh = document.querySelector("#빈칸")

    container.style.width = "200px";
    container.style.height = "200px";
    container.style.backgroundColor = "yellow"
    container.style.border = "3px solid black"

    for(let i=0 ; i<tagList.length ; i++){
       
    }
    

    bg.innerHTML=`<p><span>${input.value}</span></p>`;

    
}
